import React from 'react'

const Sign = () => {
  return (
    <div>Sign Up</div>
  )
}

export default Sign